exports.handler = async (_, context) => {
    console.log(`string inverter`);
}